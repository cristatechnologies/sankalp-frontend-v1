import React from "react";
import PhonePePayment from "../../src/components/PhonePePayment";
import PageHead from "../../src/components/Helpers/PageHead";
import Layout from "../../src/components/Partials/Layout";

function PhonePe() {
  return (
    <>
            <PhonePePayment/>  
    </>
  );
}
export default PhonePe;
