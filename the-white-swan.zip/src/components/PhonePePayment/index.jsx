import axios from 'axios';
import React from 'react'

const PhonePePayment = () => {
    
  return (
    <div>index</div>
  )
}

export default PhonePePayment;